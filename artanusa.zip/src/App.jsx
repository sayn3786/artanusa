
import ArtaNusaShop from "./ArtaNusaShop";
export default function App() {
  return <ArtaNusaShop />;
}
